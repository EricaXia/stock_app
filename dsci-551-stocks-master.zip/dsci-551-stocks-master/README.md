# DSCI 551 Group Project - Fall 2020
 Github repo to store code for our DSCI 551 stock prices project.
